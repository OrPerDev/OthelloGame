﻿using System;
using System.Drawing;
using System.Windows.Forms;


namespace A23_Ex05_Othello.Forms
{
    public partial class GameBoardForm : Form
    {
        // Events
        public event EventHandler MovePlayedEventHandler;

        // Util members
        private readonly int r_PictureBoxSize = 60;
        private readonly int r_BoardTopStartingPosition = 40;
        private readonly int r_BoardLeftStartingPosition = 15;
        private readonly Bitmap r_RedCoin = Properties.Resources.CoinRed;
        private readonly Bitmap r_YellowCoin = Properties.Resources.CoinYellow;

        // Members
        private readonly OthelloDiskPicture[,] r_BoardDisksPictureBox;
        private readonly Label r_ScoreLabel;

        // Constractors
        public GameBoardForm(int io_BoardSize, string o_FirstPlayerName, string o_SecondPlayerName)
        {
            InitializeComponent();
            this.ClientSize = new Size(
                (io_BoardSize * r_PictureBoxSize) + (2 * r_BoardLeftStartingPosition) + io_BoardSize,
                (io_BoardSize * r_PictureBoxSize) + (2 * r_BoardTopStartingPosition));

            this.r_ScoreLabel = new Label();
            this.initBoardLabel(o_FirstPlayerName, o_SecondPlayerName);

            this.r_BoardDisksPictureBox = new OthelloDiskPicture[io_BoardSize, io_BoardSize];
            this.initBoard(io_BoardSize);
            this.MaximizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        // Properties
        internal OthelloDiskPicture[,] BoardPictures
        {
            get
            {
                return this.r_BoardDisksPictureBox;
            }
        }

        internal Bitmap RedCoin
        {
            get
            {
                return this.r_RedCoin;
            }
        }

        internal Bitmap YellowCoin
        {
            get
            {
                return this.r_YellowCoin;
            }
        }

        internal Label ScoreBoard
        {
            get
            {
                return this.r_ScoreLabel;
            }
        }

        // Methods
        private void initBoard(int i_BoardSize)
        {
            Point currentPicturePoint = new Point(
                this.Location.X + this.r_BoardLeftStartingPosition,
                this.Location.Y + this.r_BoardTopStartingPosition);
            OthelloDiskPicture[,] boardPictures = this.BoardPictures;
            for (int i = 0; i < i_BoardSize; i++)
            {
                for (int j = 0; j < i_BoardSize; j++)
                {
                    boardPictures[i, j] = new OthelloDiskPicture(i, j);
                    boardPictures[i, j].Size = new Size(this.r_PictureBoxSize, this.r_PictureBoxSize);
                    boardPictures[i, j].BackColor = Color.LightGray;
                    boardPictures[i, j].Location = currentPicturePoint;
                    boardPictures[i, j].Enabled = false;
                    boardPictures[i, j].Click += OthelloPcitureBox_Click;
                    currentPicturePoint.X += this.r_PictureBoxSize + 1;
                    this.Controls.Add(boardPictures[i, j]);
                }

                currentPicturePoint.X = this.Location.X + this.r_BoardLeftStartingPosition;
                currentPicturePoint.Y += this.r_PictureBoxSize + 1;
            }
        }

        private void initBoardLabel(string i_FirstPlayerName, string i_SecondPlayerName)
        {
            this.r_ScoreLabel.Text = @$"Score :
{i_FirstPlayerName} {i_SecondPlayerName}";
            this.r_ScoreLabel.AutoSize = true;
            this.r_ScoreLabel.Location = new Point(this.Location.X + (this.Size.Width / 2) - this.r_ScoreLabel.Width, this.Location.Y);
            this.r_ScoreLabel.TextAlign = ContentAlignment.MiddleCenter;
            this.Controls.Add(r_ScoreLabel);
        }

        private void OthelloPcitureBox_Click(object sender, EventArgs e)
        {
            this.MovePlayedEventHandler?.Invoke(sender, e);
        }
    }
}
