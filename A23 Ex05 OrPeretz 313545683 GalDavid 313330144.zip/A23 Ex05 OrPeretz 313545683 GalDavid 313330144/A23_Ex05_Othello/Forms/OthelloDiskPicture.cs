﻿using System.Windows.Forms;
using A23_Ex05_Othello.Logic;

namespace A23_Ex05_Othello.Forms
{
    internal class OthelloDiskPicture : PictureBox
    {
        // Members
        private readonly DiskPosition r_DiskPosition;

        // Constractors
        internal OthelloDiskPicture(int i_Row, int i_Col)
        {
            this.r_DiskPosition = new DiskPosition(i_Row, i_Col);
        }

        // Properties
        internal DiskPosition Position
        {
            get
            {
                return this.r_DiskPosition;
            }
        }
    }
}
