using System;

namespace A23_Ex05_Othello
{
    public static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            GameController gameController = new GameController();
        }
    }
}
